#include "duckdb/function/aggregate_function.hpp"

namespace duckdb {

AggregateFunctionInfo::~AggregateFunctionInfo() {
}

} // namespace duckdb
